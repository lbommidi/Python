from django.conf.urls import url

from . import views

urlpatterns = [
    # ex: /hello/
    url(r'^$', views.hello, name='hello'),
    url(r'^article/(\d+)/$', views.viewArticle, name='article'),

]
