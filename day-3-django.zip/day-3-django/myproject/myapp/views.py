from django.shortcuts import render

# Create your views here.
import datetime
from django.http import HttpResponse

def viewArticle (request, articleId):
    text="Displaying article number :  %s" %articleId
    return HttpResponse(text)


#ef hello(request):
#   today=datetime.datetime.now().date()
#   return render(request,"hello.html",{"today": today})
# # return render(request, "myapp/template/hello.html",{})


def hello(request):
    text= """ <h1> Welcome to my app !! <h1>"""
    return HttpResponse(text)
   # return render(request, "myapp/template/hello.html",{})
