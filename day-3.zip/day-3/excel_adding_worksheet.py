import openpyxl
wb = openpyxl.load_workbook('sample.xlsx')
newws=wb.create_sheet(index=0,title="sheet2")
print(wb.get_sheet_names())
wb.save('sample.xlsx')
wb.close()