from docx import Document
document = Document()
#document = Document('existing-document-file.docx')
document.add_heading('The REAL meaning of the universe')
document.add_heading('The role of dolphins', level=2)
paragraph = document.add_paragraph('It is easy to learn python')
document.save('mydocument.docx')

