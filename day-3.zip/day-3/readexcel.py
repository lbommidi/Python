#from openpyxl import Workbook

import openpyxl
wb = openpyxl.load_workbook('sample.xlsx')
ws=wb.get_sheet_by_name('Sheet')
cell= ws['A2']
print(" Cell contents -", cell.value)
for i in range(1,4,1):
    print(i, ws.cell(row=2,column=i).value)
wb.close()

