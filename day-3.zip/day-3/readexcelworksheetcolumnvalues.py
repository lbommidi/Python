
import openpyxl
wb = openpyxl.load_workbook('sample.xlsx')
ws=wb.get_sheet_by_name('Sheet')
# reading values of first column
for cellobj in ws.columns:
    print(cellobj)

wb.close()